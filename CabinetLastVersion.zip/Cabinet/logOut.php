<?php 
session_destroy();
header('Location: /Cabinet/Authentification.php'); 

?>